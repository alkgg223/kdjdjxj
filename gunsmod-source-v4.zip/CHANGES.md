# Guns and Bots v4 — what changed

* Weapons: real 3D OBJ models (profile-extruded, round barrels, angled grips, rails, sights) instead of cuboids.
  Generated per gun x 7 paints; attachments are separate parts drawn by `GunItemRenderer`.
* Optics (7): Red Dot, 4x, Holographic, ACOG 3x, 8x Long Range, Thermal (+ sniper built-in) with distinct reticles / lens views.
* Muzzle (5): Suppressor, Compensator, Flash Hider, Muzzle Brake, Bayonet.
* Underbarrel (4): Vertical Grip, Angled Grip, Laser Module, Bipod.
* Ammo types (4): FMJ, Hollow Point, Armor Piercing, Incendiary.
* New UI: Workbench (scrolling list, 3D preview, Requires row, Craft / x5) and Customizer (5 categories, rotatable 3D preview, stats bars).
* New HUD: big ammo counter, reserve, fire mode, armor bar, hit counter ("N dmg / M hits"), floating damage numbers, hit marker, custom crosshair.
* Particles: muzzle flash / smoke / explosion frames sliced from the supplied pixel-art sheet (exp_0..17).
