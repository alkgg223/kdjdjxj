package com.example.gunsmod;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.ItemBlockRenderTypes;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.BlockEntityWithoutLevelRenderer;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.client.resources.model.ModelResourceLocation;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/** Draws a gun's 3D body (per paint) plus its optic / muzzle / underbarrel attachments. Client only. */
public class GunItemRenderer extends BlockEntityWithoutLevelRenderer {
    /** Mount points in model units: {muzzleX, barrelY, barrelRadius, railY, railX, underY, underX}. */
    public static float[] anchors(GunType t) {
        return switch (t) {
            case PISTOL -> new float[]{3.25f, 8.2f, 0.32f, 9.5f, 8.2f, 6.1f, 6.0f};
            case DEAGLE -> new float[]{2.6f, 8.3f, 0.42f, 10.5f, 8.6f, 5.9f, 5.5f};
            case SMG -> new float[]{0.0f, 8.4f, 0.34f, 9.65f, 7.0f, 7.1f, 2.6f};
            case RIFLE -> new float[]{0.6f, 9.0f, 0.32f, 10.9f, 8.4f, 7.5f, 4.8f};
            case M4 -> new float[]{0.8f, 9.0f, 0.30f, 10.85f, 7.2f, 8.1f, 5.6f};
            case SHOTGUN -> new float[]{0.6f, 8.0f, 0.45f, 9.2f, 11.4f, 5.2f, 6.0f};
            case SNIPER -> new float[]{0.6f, 8.2f, 0.40f, -1f, 0f, 6.1f, 5.5f};
            case LMG -> new float[]{0.6f, 8.8f, 0.40f, 11.0f, 10.4f, 7.8f, 5.4f};
            case RPG -> new float[]{0f, 9.0f, 0f, 11.8f, 7.6f, 0f, 0f};
            default -> new float[]{0f, 8.2f, 0f, 12.7f, 7.6f, 0f, 0f};
        };
    }

    private static ResourceLocation rl(String p) {
        return ResourceLocation.fromNamespaceAndPath(GunsMod.MODID, p);
    }

    public static ModelResourceLocation mrl(String path) {
        return ModelResourceLocation.standalone(rl(path));
    }

    public static String gunModelName(GunType t, int paint) {
        return "gunmodel/" + t.name().toLowerCase(java.util.Locale.ROOT) + "_p" + paint;
    }

    public GunItemRenderer() {
        super(Minecraft.getInstance().getBlockEntityRenderDispatcher(), Minecraft.getInstance().getEntityModels());
    }

    private static BakedModel get(String path) {
        return Minecraft.getInstance().getModelManager().getModel(mrl(path));
    }

    @Override
    public void renderByItem(ItemStack stack, ItemDisplayContext ctx, PoseStack ps, MultiBufferSource buf, int light, int overlay) {
        if (!(stack.getItem() instanceof GunItem g)) return;
        ItemRenderer ir = Minecraft.getInstance().getItemRenderer();
        VertexConsumer vc = buf.getBuffer(ItemBlockRenderTypes.getRenderType(stack, true));
        int paint = Math.max(0, Math.min(Paints.COUNT - 1, GunItem.getPaint(stack)));
        ir.renderModelLists(get(gunModelName(g.type, paint)), stack, light, overlay, ps, vc);

        float[] a = anchors(g.type);
        int scope = GunItem.getScope(stack);
        if (scope > 0 && !g.type.scoped && a[3] > 0) {
            ps.pushPose();
            ps.translate(a[4] / 16f, a[3] / 16f, 0f);
            ir.renderModelLists(get("gunmodel/part/optic_" + scope), stack, light, overlay, ps, vc);
            ps.popPose();
        }
        int muzzle = GunItem.getMuzzle(stack);
        if (muzzle > 0 && GunItem.supportsMuzzle(g.type)) {
            ps.pushPose();
            ps.translate(a[0] / 16f, a[1] / 16f, 0.5f);
            float s = (a[2] + 0.3f) / 0.65f;
            ps.scale(1f, s, s);
            ps.translate(0f, 0f, -0.5f);
            ir.renderModelLists(get("gunmodel/part/muzzle_" + muzzle), stack, light, overlay, ps, vc);
            ps.popPose();
        }
        int under = GunItem.getUnder(stack);
        if (under > 0 && GunItem.supportsUnder(g.type)) {
            ps.pushPose();
            ps.translate(a[6] / 16f, a[5] / 16f, 0f);
            ir.renderModelLists(get("gunmodel/part/under_" + under), stack, light, overlay, ps, vc);
            ps.popPose();
        }
    }
}
