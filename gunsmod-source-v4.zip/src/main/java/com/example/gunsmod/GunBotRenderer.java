package com.example.gunsmod;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

public class GunBotRenderer extends HumanoidMobRenderer<GunBotEntity, HumanoidModel<GunBotEntity>> {
    private static final ResourceLocation ALLY_SKIN =
            ResourceLocation.withDefaultNamespace("textures/entity/player/wide/steve.png");
    private static final ResourceLocation ENEMY_SKIN =
            ResourceLocation.withDefaultNamespace("textures/entity/player/wide/zuri.png");

    public GunBotRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.5f);
    }

    @Override
    public ResourceLocation getTextureLocation(GunBotEntity bot) {
        return bot.isAlly() ? ALLY_SKIN : ENEMY_SKIN;
    }

    @Override
    public void render(GunBotEntity bot, float yaw, float partial, PoseStack ps, MultiBufferSource buf, int light) {
        HumanoidModel.ArmPose pose = bot.getMainHandItem().isEmpty()
                ? HumanoidModel.ArmPose.EMPTY
                : HumanoidModel.ArmPose.BOW_AND_ARROW;
        this.model.rightArmPose = pose;
        super.render(bot, yaw, partial, ps, buf, light);
    }
}
